import csv

def panjang(x):
    len = 0
    for i in x:
        len  = len + 1
    return(len)   